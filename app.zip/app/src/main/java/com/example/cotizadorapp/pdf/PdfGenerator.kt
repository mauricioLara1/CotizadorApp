package com.example.cotizadorapp.pdf

class PdfGenerator {
}