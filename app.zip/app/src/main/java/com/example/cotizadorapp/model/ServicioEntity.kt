package com.example.cotizadorapp.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(
    tableName = "servicio",
    foreignKeys = [
        ForeignKey(
            entity = PerfilEntity::class,
            parentColumns = ["perfilId"],
            childColumns = ["perfilId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class ServicioEntity(
    @PrimaryKey(autoGenerate = true)
    val servicioId: Long = 0L,
    val perfilId: Long, // FK hacia Perfil
    val cliente: String,
    val descripcion: String,
    val costoTotal: Double
)
